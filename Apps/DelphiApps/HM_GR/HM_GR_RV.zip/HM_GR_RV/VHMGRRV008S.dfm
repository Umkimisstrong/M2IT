object Form118: TForm118
  Left = 2256
  Top = 138
  Width = 1286
  Height = 748
  Caption = #44277#45800' '#49688#44160#51221#48372' '#50672#44228' [VHMGRRV008S]'
  Color = clWhite
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object FlatPanel4: TFlatPanel
    Left = 0
    Top = 0
    Width = 1266
    Height = 705
    ParentColor = True
    TabOrder = 0
    UseDockManager = True
    object FlatPanel1: TFlatPanel
      Left = 1
      Top = 1
      Width = 1264
      Height = 32
      ParentColor = True
      TabOrder = 0
      UseDockManager = True
      object FlatLabel2: TFlatLabel
        Left = 9
        Top = 7
        Width = 69
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #49468#53552#44396#48516
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatLabel1: TFlatLabel
        Left = 201
        Top = 5
        Width = 71
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51217#49688#51068#51088
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object Label20: TLabel
        Left = 369
        Top = 4
        Width = 16
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = '~'
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        ParentFont = False
        Layout = tlCenter
      end
      object Label2: TLabel
        Left = 672
        Top = 5
        Width = 89
        Height = 23
        Alignment = taRightJustify
        AutoSize = False
        Caption = #44160#51652#51109#49548
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        ParentFont = False
        Layout = tlCenter
      end
      object FlatLabel3: TFlatLabel
        Left = 489
        Top = 6
        Width = 71
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #51217#49688#52376
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = False
        ShowEssential = True
      end
      object FlatComboBox1: TFlatComboBox
        Left = 76
        Top = 5
        Width = 100
        Height = 21
        Color = clWindow
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ItemHeight = 13
        ParentFont = False
        TabOrder = 0
        ItemIndex = -1
      end
      object FlatComboBox2: TFlatComboBox
        Left = 268
        Top = 5
        Width = 100
        Height = 21
        Color = clWindow
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ItemHeight = 13
        ParentFont = False
        TabOrder = 1
        ItemIndex = -1
      end
      object FlatComboBox4: TFlatComboBox
        Left = 390
        Top = 5
        Width = 100
        Height = 21
        Color = clWindow
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ItemHeight = 13
        ParentFont = False
        TabOrder = 2
        ItemIndex = -1
      end
      object FlatPanel2: TFlatPanel
        Left = 764
        Top = 5
        Width = 125
        Height = 23
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        ParentColor = True
        TabOrder = 3
        UseDockManager = True
        object FlatRadioButton6: TFlatRadioButton
          Left = 6
          Top = 3
          Width = 67
          Height = 17
          Caption = #45236#50896
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = #45208#45588#44256#46357
          Font.Style = []
          ParentFont = False
          TabOrder = 0
        end
        object FlatRadioButton10: TFlatRadioButton
          Left = 74
          Top = 3
          Width = 47
          Height = 17
          Caption = #52636#51109
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = #45208#45588#44256#46357
          Font.Style = []
          ParentFont = False
          TabOrder = 1
        end
      end
      object FlatButton7: TFlatButton
        Left = 1187
        Top = 5
        Width = 70
        Height = 23
        Color = clSilver
        Caption = #51312#54924
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        ParentFont = False
        ParentColor = False
        TabOrder = 4
      end
      object FlatComboBox3: TFlatComboBox
        Left = 561
        Top = 5
        Width = 100
        Height = 21
        Color = clWindow
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ItemHeight = 13
        ParentFont = False
        TabOrder = 5
        ItemIndex = -1
      end
    end
    object FlatPanel5: TFlatPanel
      Left = 1
      Top = 33
      Width = 1264
      Height = 33
      ParentColor = True
      TabOrder = 1
      UseDockManager = True
      object FlatComboBox14: TFlatComboBox
        Left = 1188
        Top = 5
        Width = 69
        Height = 23
        Color = clWindow
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        ItemHeight = 15
        ParentFont = False
        TabOrder = 0
        Text = '  Action'
        ItemIndex = -1
      end
    end
    object FlatPanel10: TFlatPanel
      Left = 1
      Top = 99
      Width = 1264
      Height = 605
      ParentColor = True
      TabOrder = 2
      UseDockManager = True
      object AdvStringGrid4: TAdvStringGrid
        Left = 1
        Top = 1
        Width = 1262
        Height = 603
        Cursor = crDefault
        Align = alClient
        Color = clWhite
        ColCount = 23
        DefaultRowHeight = 25
        DefaultDrawing = False
        FixedCols = 0
        RowCount = 40
        FixedRows = 1
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        GridLineWidth = 1
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goDrawFocusSelected]
        ParentFont = False
        TabOrder = 0
        GridLineColor = clSilver
        ActiveCellShow = False
        ActiveCellFont.Charset = DEFAULT_CHARSET
        ActiveCellFont.Color = clWindowText
        ActiveCellFont.Height = -11
        ActiveCellFont.Name = 'MS Sans Serif'
        ActiveCellFont.Style = [fsBold]
        ActiveCellColor = clGray
        Bands.PrimaryColor = clInfoBk
        Bands.PrimaryLength = 1
        Bands.SecondaryColor = clWindow
        Bands.SecondaryLength = 1
        Bands.Print = False
        AutoNumAlign = False
        AutoSize = False
        VAlignment = vtaTop
        EnhTextSize = False
        EnhRowColMove = False
        SizeWithForm = False
        Multilinecells = False
        DragDropSettings.OleAcceptFiles = True
        DragDropSettings.OleAcceptText = True
        SortSettings.AutoColumnMerge = False
        SortSettings.Column = 0
        SortSettings.Show = False
        SortSettings.IndexShow = False
        SortSettings.IndexColor = clYellow
        SortSettings.Full = True
        SortSettings.SingleColumn = False
        SortSettings.IgnoreBlanks = False
        SortSettings.BlankPos = blFirst
        SortSettings.AutoFormat = True
        SortSettings.Direction = sdAscending
        SortSettings.FixedCols = False
        SortSettings.NormalCellsOnly = False
        SortSettings.Row = 0
        FloatingFooter.Color = clBtnFace
        FloatingFooter.Column = 0
        FloatingFooter.FooterStyle = fsFixedLastRow
        FloatingFooter.Visible = False
        ControlLook.Color = clBlack
        ControlLook.CheckSize = 15
        ControlLook.RadioSize = 10
        ControlLook.ControlStyle = csClassic
        ControlLook.FlatButton = False
        EnableBlink = False
        EnableHTML = True
        EnableWheel = True
        Flat = False
        HintColor = clInfoBk
        SelectionColor = clHighlight
        SelectionTextColor = clHighlightText
        SelectionRectangle = False
        SelectionResizer = False
        SelectionRTFKeep = False
        HintShowCells = False
        HintShowLargeText = False
        HintShowSizing = False
        PrintSettings.FooterSize = 0
        PrintSettings.HeaderSize = 0
        PrintSettings.Time = ppNone
        PrintSettings.Date = ppNone
        PrintSettings.DateFormat = 'dd/mm/yyyy'
        PrintSettings.PageNr = ppNone
        PrintSettings.Title = ppNone
        PrintSettings.Font.Charset = DEFAULT_CHARSET
        PrintSettings.Font.Color = clWindowText
        PrintSettings.Font.Height = -11
        PrintSettings.Font.Name = 'MS Sans Serif'
        PrintSettings.Font.Style = []
        PrintSettings.HeaderFont.Charset = DEFAULT_CHARSET
        PrintSettings.HeaderFont.Color = clWindowText
        PrintSettings.HeaderFont.Height = -11
        PrintSettings.HeaderFont.Name = 'MS Sans Serif'
        PrintSettings.HeaderFont.Style = []
        PrintSettings.FooterFont.Charset = DEFAULT_CHARSET
        PrintSettings.FooterFont.Color = clWindowText
        PrintSettings.FooterFont.Height = -11
        PrintSettings.FooterFont.Name = 'MS Sans Serif'
        PrintSettings.FooterFont.Style = []
        PrintSettings.Borders = pbNoborder
        PrintSettings.BorderStyle = psSolid
        PrintSettings.Centered = False
        PrintSettings.RepeatFixedRows = False
        PrintSettings.RepeatFixedCols = False
        PrintSettings.LeftSize = 0
        PrintSettings.RightSize = 0
        PrintSettings.ColumnSpacing = 0
        PrintSettings.RowSpacing = 0
        PrintSettings.TitleSpacing = 0
        PrintSettings.Orientation = poPortrait
        PrintSettings.PageNumberOffset = 0
        PrintSettings.MaxPagesOffset = 0
        PrintSettings.FixedWidth = 0
        PrintSettings.FixedHeight = 0
        PrintSettings.UseFixedHeight = False
        PrintSettings.UseFixedWidth = False
        PrintSettings.FitToPage = fpNever
        PrintSettings.PageNumSep = '/'
        PrintSettings.NoAutoSize = False
        PrintSettings.NoAutoSizeRow = False
        PrintSettings.PrintGraphics = False
        HTMLSettings.Width = 100
        HTMLSettings.XHTML = False
        Navigation.AdvanceDirection = adLeftRight
        Navigation.InsertPosition = pInsertBefore
        Navigation.HomeEndKey = heFirstLastColumn
        Navigation.TabToNextAtEnd = False
        Navigation.TabAdvanceDirection = adLeftRight
        ColumnSize.Location = clRegistry
        CellNode.Color = clSilver
        CellNode.NodeColor = clBlack
        CellNode.ShowTree = False
        MaxEditLength = 0
        IntelliPan = ipVertical
        URLColor = clBlue
        URLShow = False
        URLFull = False
        URLEdit = False
        ScrollType = ssNormal
        ScrollColor = clNone
        ScrollWidth = 17
        ScrollSynch = False
        ScrollProportional = False
        ScrollHints = shNone
        OemConvert = False
        FixedFooters = 0
        FixedRightCols = 0
        FixedColWidth = 96
        FixedRowHeight = 32
        FixedFont.Charset = DEFAULT_CHARSET
        FixedFont.Color = clWindowText
        FixedFont.Height = -13
        FixedFont.Name = #45208#45588#44256#46357
        FixedFont.Style = []
        FixedAsButtons = False
        FloatFormat = '%.2f'
        IntegralHeight = False
        WordWrap = False
        ColumnHeaders.Strings = (
          #51217#49688#51068#51088
          #51217#49688#48264#54840
          #49457#47749
          #49373#45380#50900#51068
          #49457#48324
          #44160#51652#51109#49548
          #44160#51652#45380#46020
          #51068#48152
          ''
          #49373#54876#49845#44288
          ''
          #50948#50516
          ''
          #50948#50516'Type'
          #45824#51109#50516
          ''
          #45824#51109#50516'Type'
          #50976#48169#50516
          ''
          #51088#44417#44221#48512#50516
          ''
          #44036#50516
          '')
        Lookup = False
        LookupCaseSensitive = False
        LookupHistory = False
        ShowSelection = False
        BackGround.Top = 0
        BackGround.Left = 0
        BackGround.Display = bdTile
        BackGround.Cells = bcNormal
        Filter = <>
        ColWidths = (
          96
          104
          131
          94
          45
          61
          89
          33
          15
          64
          12
          34
          17
          64
          44
          13
          76
          50
          13
          74
          14
          64
          15)
        RowHeights = (
          32
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25
          25)
      end
    end
    object FlatPanel9: TFlatPanel
      Left = 1
      Top = 66
      Width = 1264
      Height = 33
      ParentColor = True
      TabOrder = 3
      UseDockManager = True
      object FlatLabel6: TFlatLabel
        Left = 5
        Top = 8
        Width = 90
        BorderColor = clWhite
        Alignment = taRightJustify
        TextBorder = 2
        BevelInner = beNone
        BevelOuter = beNone
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = #45208#45588#44256#46357
        Font.Style = []
        Caption = #49688#44160#51088' '#47785#47197
        Color = clWhite
        ParentFont = False
        ParentColor = False
        ShowRect = True
        ShowEssential = False
      end
    end
  end
  object FlatPanel27: TFlatPanel
    Left = 1181
    Top = 60
    Width = 77
    Height = 25
    ParentColor = True
    TabOrder = 1
    UseDockManager = True
    object FlatButton4: TFlatButton
      Left = 0
      Top = 1
      Width = 77
      Height = 23
      Caption = #51200#51109
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = #45208#45588#44256#46357
      Font.Style = []
      ParentFont = False
      TabOrder = 0
    end
  end
end
