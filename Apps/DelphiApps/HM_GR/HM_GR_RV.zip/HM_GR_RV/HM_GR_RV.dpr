program HM_GR_RV;

uses
  Forms,
  VHMGRRV016S in 'VHMGRRV016S.pas' {Form1},
  VHMGRRV018S in 'VHMGRRV018S.pas' {Form5},
  VHMGRRV020S in 'VHMGRRV020S.pas' {Form6},
  VHMGRRV034S in 'VHMGRRV034S.pas' {Form7},
  VHMGRRV037S in 'VHMGRRV037S.pas' {Form8},
  VHMGRRV047S in 'VHMGRRV047S.pas' {Form9},
  VHMGRRV048S in 'VHMGRRV048S.pas' {Form10},
  VHMGRRV016S01 in 'VHMGRRV016S01.pas' {Form11},
  VHMGRRV016S05 in 'VHMGRRV016S05.pas' {Form12},
  VHMGRRV016S07 in 'VHMGRRV016S07.pas' {Form13},
  VHMGRRV016S08 in 'VHMGRRV016S08.pas' {Form14},
  VHMGRRV016S09 in 'VHMGRRV016S09.pas' {Form15},
  VHMGRRV016S11 in 'VHMGRRV016S11.pas' {Form16},
  VHMGRRV016S13 in 'VHMGRRV016S13.pas' {Form17},
  VHMGRRV001S in 'VHMGRRV001S.pas' {Form113},
  VHMGRRV002S in 'VHMGRRV002S.pas' {Form114},
  VHMGRRV003S in 'VHMGRRV003S.pas' {Form115},
  VHMGRRV004S in 'VHMGRRV004S.pas' {Form116},
  VHMGRRV006S in 'VHMGRRV006S.pas' {Form117},
  VHMGRRV008S in 'VHMGRRV008S.pas' {Form118},
  VHMGRRV009S in 'VHMGRRV009S.pas' {Form119},
  VHMGRRV010S in 'VHMGRRV010S.pas' {Form120},
  VHMGRRV013S in 'VHMGRRV013S.pas' {Form121},
  VHMGRRV014S in 'VHMGRRV014S.pas' {Form122},
  VHMGRRV015S in 'VHMGRRV015S.pas' {Form123},
  VHMGRRV017S in 'VHMGRRV017S.pas' {Form124},
  VHMGRRV019S in 'VHMGRRV019S.pas' {Form125},
  VHMGRRV021S in 'VHMGRRV021S.pas' {Form126},
  VHMGRRV022S in 'VHMGRRV022S.pas' {Form127},
  VHMGRRV023S in 'VHMGRRV023S.pas' {Form128},
  VHMGRRV024S in 'VHMGRRV024S.pas' {Form129},
  VHMGRRV027S in 'VHMGRRV027S.pas' {Form130},
  VHMGRRV028S in 'VHMGRRV028S.pas' {Form131},
  VHMGRRV029S in 'VHMGRRV029S.pas' {Form132},
  VHMGRRV030S in 'VHMGRRV030S.pas' {Form133},
  VHMGRRV031S in 'VHMGRRV031S.pas' {Form134},
  VHMGRRV032S in 'VHMGRRV032S.pas' {Form135},
  VHMGRRV033S in 'VHMGRRV033S.pas' {Form136},
  VHMGRRV035S in 'VHMGRRV035S.pas' {Form137},
  VHMGRRV036S in 'VHMGRRV036S.pas' {Form138},
  VHMGRRV038S in 'VHMGRRV038S.pas' {Form139},
  VHMGRRV039S in 'VHMGRRV039S.pas' {Form140},
  VHMGRRV040S in 'VHMGRRV040S.pas' {Form141},
  VHMGRRV041S in 'VHMGRRV041S.pas' {Form142},
  VHMGRRV042S in 'VHMGRRV042S.pas' {Form143},
  VHMGRRV043S in 'VHMGRRV043S.pas' {Form144},
  VHMGRRV046S in 'VHMGRRV046S.pas' {Form145},
  VHMGRRV049S in 'VHMGRRV049S.pas' {Form146},
  VHMGRRV050S in 'VHMGRRV050S.pas' {Form147};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm5, Form5);
  Application.CreateForm(TForm6, Form6);
  Application.CreateForm(TForm7, Form7);
  Application.CreateForm(TForm8, Form8);
  Application.CreateForm(TForm9, Form9);
  Application.CreateForm(TForm10, Form10);
  Application.CreateForm(TForm11, Form11);
  Application.CreateForm(TForm12, Form12);
  Application.CreateForm(TForm13, Form13);
  Application.CreateForm(TForm14, Form14);
  Application.CreateForm(TForm15, Form15);
  Application.CreateForm(TForm16, Form16);
  Application.CreateForm(TForm17, Form17);
  Application.CreateForm(TForm113, Form113);
  Application.CreateForm(TForm114, Form114);
  Application.CreateForm(TForm115, Form115);
  Application.CreateForm(TForm116, Form116);
  Application.CreateForm(TForm117, Form117);
  Application.CreateForm(TForm118, Form118);
  Application.CreateForm(TForm119, Form119);
  Application.CreateForm(TForm120, Form120);
  Application.CreateForm(TForm121, Form121);
  Application.CreateForm(TForm122, Form122);
  Application.CreateForm(TForm123, Form123);
  Application.CreateForm(TForm124, Form124);
  Application.CreateForm(TForm125, Form125);
  Application.CreateForm(TForm126, Form126);
  Application.CreateForm(TForm127, Form127);
  Application.CreateForm(TForm128, Form128);
  Application.CreateForm(TForm129, Form129);
  Application.CreateForm(TForm130, Form130);
  Application.CreateForm(TForm131, Form131);
  Application.CreateForm(TForm132, Form132);
  Application.CreateForm(TForm133, Form133);
  Application.CreateForm(TForm134, Form134);
  Application.CreateForm(TForm135, Form135);
  Application.CreateForm(TForm136, Form136);
  Application.CreateForm(TForm137, Form137);
  Application.CreateForm(TForm138, Form138);
  Application.CreateForm(TForm139, Form139);
  Application.CreateForm(TForm140, Form140);
  Application.CreateForm(TForm141, Form141);
  Application.CreateForm(TForm142, Form142);
  Application.CreateForm(TForm143, Form143);
  Application.CreateForm(TForm144, Form144);
  Application.CreateForm(TForm145, Form145);
  Application.CreateForm(TForm146, Form146);
  Application.CreateForm(TForm147, Form147);
  Application.Run;
end.
